package testing;

//import java.io.File;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/**
		 * AVL Test.
		 */
//		 AVLTree<Integer> tree = new AVLTree<Integer>(true);
//		 tree.insert(8);
//		 tree.insert(9);
//		 tree.insert(10);
//		 tree.insert(13);
//		 tree.insert(14);
//		 tree.insert(15);
//		 tree.insert(16);
//		 System.out.println("result 10= " +tree.search(10));
//		 System.out.println("result 8= " +tree.search(8));
//		 System.out.println("result 9= " +tree.search(9));
//		 System.out.println("result 14= " +tree.search(14));
//		 System.out.println("result 16= " +tree.search(16));
//		 System.out.println("result 20= " +tree.search(20));
//		 System.out.println("result 5= " +tree.search(5));
//		 System.out.println("result 3= " +tree.search(3));
//		 System.out.println("result 13= " +tree.search(13));
//		 System.out.println("result 15= " +tree.search(15));
//		 tree.inOrder();
//		 tree.delete(15);
//		 System.out.println("\n");
//		 tree.inOrder();
		
		/**
		 * Dictionary Test.
		 */
//		 IDictionary dictionary = new Dictionary();
//		 String cPath = System.getProperty("user.home") , fileName =
//		 "\\dic.txt";
//		 File file = new File(cPath+fileName);
//		 dictionary.load(file);
//		 System.out.println(dictionary.size());
//		 System.out.println(dictionary.exists("ziad"));
//		 System.out.println(dictionary.exists("faN"));
//		 System.out.println(dictionary.insert("ziad"));
//		 System.out.println(dictionary.exists("zoo"));
//		 System.out.println(dictionary.size());
//		 System.out.println(dictionary.insert("zoo"));
//		 System.out.println(dictionary.exists("zoo"));
//		 System.out.println(dictionary.delete("ziad"));
//		 System.out.println(dictionary.exists("ziad"));
//		 System.out.println(dictionary.insert("ziad"));
//		 System.out.println(dictionary.size());
//		 System.out.println(dictionary.height());
	}
}