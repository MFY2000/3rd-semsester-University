# Dictionary-using-AVL-tree
## About
> An efficient Dictionary which It's implemented using AVL tree data structure.<br>
> We can efficiently insert, search and delete words from our dictionary.
## Implementation
#### Used data structure
* <b>AVL tree:</b> It's a BST with lookup, insertion and deletion of order <b>O(log(n))</b>,<br> Our AVL tree supports duplication.
